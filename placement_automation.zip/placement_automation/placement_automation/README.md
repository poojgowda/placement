# Placement Automation System Using PHP

This project is created for the training and placement department for the automation of campus drives, and generation of reports.
